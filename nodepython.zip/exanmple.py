print("Big red button has been poked");
f = open('file.txt','w')
f.write("success")
f.close()
